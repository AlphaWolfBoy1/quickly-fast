-- mod made for ugx realms by dylanfreddys aka shadow-wolf

-- minetest registed tools, blocks and nodes

-- shadow_dimension:(node)

minetest.register_tool("shadow_dimension:gloomy_drill", {
	description = "Gloomy Drill",
	inventory_image = "drill.png",
	tool_capabilities = {
		full_punch_interval = 0.001,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=0.01, [2]=0.01, [3]=0.01}, uses=10000, maxlevel=3},
			weryhard = {times={[3]=0.01, [2]=0.01, [1]=0.01, [0]=0.01}, uses=10000, maxlevel=3},
			crumbly = {times={[1]=0.01, [2]=0.01, [3]=0.01}, uses=10000, maxlevel=3},
		},
		damage_groups = {fleshy=10},
	},
})

minetest.register_tool("shadow_dimension:shadowbloodwolfsword", {
	description = ("Shadow Blood Wolf Sword"),
	inventory_image = "shadowbloodwolfsword.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 2.5,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 3000},
	},
})

minetest.register_node("shadow_dimension:dirt_with_shadowgrass", {
	description = ("Dirt with Shadow Grass"),
	tiles = {"shadowgrass.png", "shadowdirt.png",
		{name = "shadowdirt.png^shadowgrass_side.png",
			tileable_vertical = false}},
	groups = {crumbly = 3, soil = 1, spreading_dirt_type = 1},
	drop = "shadow_dimension:shadow_dirt",
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})

minetest.register_node("shadow_dimension:darkshadowblock", {
    description = "Shadow Dimension Block",
    tiles = {"shadark.png"},
    light_source = 0,
    groups = {cracky = 4},
})

minetest.register_node("shadow_dimension:nightblock", {
    description = "Night Block",
    tiles = {"nightblock.png"},
    light_source = 10,
    groups = {cracky = 3},
})


minetest.register_craftitem("shadow_dimension:cookie", {
	description = ("Shadow Cookie"),
	inventory_image = "cookie.png",
	on_use = minetest.item_eat(16),
	groups = {compostability = 1}
})

minetest.register_node("shadow_dimension:purgatory", {
    description = "Purgatory block",
    tiles = {"purgatoryblock.png"},
    light_source = 1,
    groups = {cracky = 2},
})


minetest.register_node("shadow_dimension:purgatory2", {
    description = "Purgatory2 Block",
    tiles = {"purgatoryblock2.png"},
    light_source = 1,
    groups = {cracky = 2},
})

minetest.register_node("shadow_dimension:dark_blood", {
    description = "Dark Shadow Blood Block",
    tiles = {"darkblood.png"},
    light_source = 0,
    groups = {cracky = 4},
})

minetest.register_node("shadow_dimension:shadow_stone", {
	description = ("Shadow Stone"),
	tiles = {"shadowstone.png"},
	groups = {cracky = 3, stone = 1},
	drop = "shadow_dimension:shadow_stone",
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("shadow_dimension:shadow_dirt", {
	description = ("Shadow Dirt"),
	tiles = {"shadowdirt.png"},
	groups = {crumbly = 3, soil = 1},
	sounds = default.node_sound_dirt_defaults(),
})



minetest.register_node("shadow_dimension:shadowgrass_1", {
	description = ("ShadowGrass"),
	drawtype = "plantlike",
	waving = 1,
	tiles = {"shadowgrass_1.png"},
	-- Use texture of a taller grass stage in inventory
	inventory_image = "shadowgrass_3.png",
	wield_image = "shadowgrass_3.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy = 3, flora = 1, attached_node = 1, grass = 1,
		normal_grass = 1, flammable = 1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-6 / 16, -0.5, -6 / 16, 6 / 16, -5 / 16, 6 / 16},
	},

	on_place = function(itemstack, placer, pointed_thing)
		-- place a random grass node
		local stack = ItemStack("shadow_dimension:shadowgrass_" .. math.random(1,5))
		local ret = minetest.item_place(stack, placer, pointed_thing)
		return ItemStack("shadow_dimension:shadowgrass_1 " ..
			itemstack:get_count() - (1 - ret:get_count()))
	end,
})

for i = 2, 5 do
	minetest.register_node("shadow_dimension:shadowgrass_" .. i, {
		description = ("ShadowGrass"),
		drawtype = "plantlike",
		waving = 1,
		tiles = {"shadowgrass_" .. i .. ".png"},
		inventory_image = "shadowgrass_" .. i .. ".png",
		wield_image = "shadowgrass_" .. i .. ".png",
		paramtype = "light",
		sunlight_propagates = true,
		walkable = false,
		buildable_to = true,
		drop = "shadow_dimension:shadowgrass_1",
		groups = {snappy = 3, flora = 1, attached_node = 1,
			not_in_creative_inventory = 1, grass = 1,
			normal_grass = 1, flammable = 1},
		sounds = default.node_sound_leaves_defaults(),
		selection_box = {
			type = "fixed",
			fixed = {-6 / 16, -0.5, -6 / 16, 6 / 16, -3 / 16, 6 / 16},
		},
	})
end

-- chest

minetest.register_node("shadow_dimension:shadowchest", {
	description = ("Shadow Chest"),
	_tt_help = ("Interdimensional inventory"),
	tiles = {
		"shadowchest_top.png", "shadowchest_top.png",
		"shadowchest_side.png", "shadowchest_side.png",
		"shadowchest_side.png", "shadowchest_front.png"
	},
	groups = {cracky = 1, choppy = 1},
	is_ground_content = false,
	sounds = default.node_sound_stone_defaults(),
	on_rotate = screwdriver.rotate_simple,
	on_construct = function(pos)
		local meta = minetest.get_meta(pos)
		meta:set_string("formspec", [[ size[8,9]
				list[current_player;enderchest;0,0;8,4;]
				list[current_player;main;0,5;8,4;]
				listring[current_player;enderchest]
				listring[current_player;main] ]],
				 default.get_hotbar_bg(0,5))

		meta:set_string("infotext", ("Shadow Chest"))
	end
})

minetest.register_on_joinplayer(function(player)
	local inv = player:get_inventory()
	inv:set_size("enderchest", 8*4)
end)

-- shadow tree

minetest.register_node("shadow_dimension:shadow_tree", {
  description = ("Shadow Tree"),
  tiles = {"shadow_tree_top.png", "shadow_tree_top.png", "shadow_tree.png"},
  paramtype2 = "facedir",
  is_ground_content = false,
  groups = {tree = 1, choppy = 2, oddly_breakable_by_hand = 1, flammable = 2},
  sounds = default.node_sound_wood_defaults(),

  on_place = minetest.rotate_node
})


minetest.register_node("shadow_dimension:shadow_wood", {
  description = ("Shadow Wood Planks"),
  paramtype2 = "facedir",
  place_param2 = 0,
  tiles = {"shadow_wood.png"},
  is_ground_content = false,
  groups = {choppy = 2, oddly_breakable_by_hand = 2, flammable = 2, wood = 1},
  sounds = default.node_sound_wood_defaults(),
})

minetest.register_node("shadow_dimension:shadow_leaves", {
  description = ("Shadow Leaves"),
  drawtype = "allfaces_optional",
  waving = 1,
  tiles = {"shadow_leaves.png"},
  special_tiles = {"shadow_leaves_simple.png"},
  paramtype = "light",
  is_ground_content = false,
  groups = {snappy = 3, leafdecay = 3, flammable = 2, leaves = 1},
  drop = {
    max_items = 1,
    items = {
      {
        -- player will get sapling with 1/50 chance
        items = {'shadow_sapling'},
        rarity = 50,
      },
      {
        -- player will get leaves only if he get no saplings,
        -- this is because max_items is 1
        items = {'shadow_dimension:shadow_leaves'},
      }
    }
  },
  sounds = default.node_sound_leaves_defaults(),

  after_place_node = default.after_place_leaves,
})


minetest.register_node("shadow_dimension:sapling", {
	description = ("Shadow Tree Sapling"),
	drawtype = "plantlike",
	tiles = {"shadow_tree_sapling.png"},
	inventory_image = "shadow_tree_sapling.png",
	wield_image = "shadow_tree_sapling.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	on_timer = grow_sapling,
	selection_box = {
		type = "fixed",
		fixed = {-4 / 16, -0.5, -4 / 16, 4 / 16, 7 / 16, 4 / 16}
	},
	groups = {snappy = 2, dig_immediate = 3, flammable = 2,
		attached_node = 1, sapling = 1},
	sounds = default.node_sound_leaves_defaults(),

	on_construct = function(pos)
		minetest.get_node_timer(pos):start(math.random(300, 1500))
	end,

	on_place = function(itemstack, placer, pointed_thing)
		itemstack = default.sapling_on_place(itemstack, placer, pointed_thing,
			"shadow_dimension:sapling",
			-- minp, maxp to be checked, relative to sapling pos
			-- minp_relative.y = 1 because sapling pos has been checked
			{x = -3, y = 1, z = -3},
			{x = 3, y = 6, z = 3},
			-- maximum interval of interior volume check
			4)

		return itemstack
	end,
})

--deco

minetest.register_decoration({
  deco_type = "schematic",
  place_on = {"shadow_dimension:dirt_with_shadowgrass"},
  sidelen = 16,
  noise_params = {
    offset = 0.0,
    --scale = -0.015,
    scale = 0.0007,
    spread = {x = 250, y = 250, z = 250},
    seed = 2,
    octaves = 3,
    persist = 0.66
  },
  biomes = {"deciduous_forest"},
  y_min = 1,
  y_max = 31000,
  flags = "place_center_x, place_center_z",
})

-- integration with bonemeal
if minetest.global_exists("bonemeal") then
  bonemeal:add_sapling(
    {
      {"shadow_dimension:shadow_tree_sapling", default.grow_sapling, "soil"}
    }
  )
end

minetest.register_craft(
  {
    output = "shadow_dimension:shadow_wood 4",
    recipe = {
      {"shadow_dimension:shadow_tree"}
    }
  }
)

-- useless items

minetest.register_craftitem("shadow_dimension:magic_steel_shadow_ingot", {
description = minetest.colorize("#17005c", "Magic Steel Shadow Ingot\n"),
    inventory_image = "shadowsteel.png",
    max_stack = 99
})

