-- dylanfreddys mod. designed for ugx realms from nininik

-- Pickaxes
minetest.register_tool("ugx1:hydro_pick", {
    description = "Hydro Pickaxe",
    inventory_image = "hydropick.png",
    wield_scale = {x = 2, y = 2, z = 1},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level=3,
        groupcaps={
            cracky = {times={[1]=0.1, [2]=0.1, [3]=0.1}, uses=0, maxlevel=3},
       crumbly = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=0, maxlevel=3},
       choppy = {times={[1]= 0.4, [2]=0.2, [3]=0.0}, uses=0, maxlevel=3},
        },
        damage_groups = {fleshy=20},
    },
})

minetest.register_tool("ugx1:sulfur_and_steel_pick", {
	description = ("Sulfur And Steel Pickaxe"),
	inventory_image = "sulfurandsteelpick.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {tool = 1, pickaxe = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level = 3,
		groupcaps={
			cracky = {
				times = {1.8, 0.8, 0.40},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 6, burns = 1},
	},
})

-- Swords

minetest.register_tool("ugx1:cardboard_sword", {
	description = ("Cardboard Sword"),
	inventory_image = "cardboardsword.png",
	tool_capabilities = {
		full_punch_interval = 1,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=8, maxlevel=1},
		},
		damage_groups = {fleshy=1.5},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1, flammable = 2}
})

minetest.register_craft({
	output = 'ugx1:cardboard_sword',
	recipe = {
		{'', 'default:paper', ''},
		{'', 'default:paper', ''},
		{'', 'default:stick', ''},
	}
})

minetest.register_tool("ugx1:hydro_sword", {
    description = "Hydro Sword",
    inventory_image = "hydrosword.png",
    wield_scale = {x = 2, y = 2, z = 1},
    tool_capabilities = {
        max_drop_level = 3,
        groupcaps = {
            fleshy = {times = {[3] = 0, [4] = 0, [6] = 0}, uses = 0, maxlevel = 3},
            choppy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
            snappy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
        },
        damage_groups = {fleshy = 45, cracky = 1, snappy = 3, choppy = 1, crumbly = 1},
    }
})

minetest.register_tool("ugx1:sulfur_and_steel_sword", {
	description = ("Sulfur And Steel Sword"),
	inventory_image = "sulfurandsteelsword.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 21, burns = 1},
	},
})

minetest.register_tool("ugx1:plasma_sword", {
    description = "Plasma Sword",
    inventory_image = "plasmasword.png",
    wield_scale = {x = 2, y = 2, z = 1},
    tool_capabilities = {
	light_source = 10, -- Texture will have a glow when dropped
        max_drop_level = 3,
        groupcaps = {
            fleshy = {times = {[3] = 0, [4] = 0, [6] = 0}, uses = 0, maxlevel = 3},
            choppy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
            snappy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
        },
		damage_groups = {fleshy = 9, burns = 1},
    },
})

minetest.register_tool("ugx1:legendtitaniumsword", {
	description = ("Legendary Titanium Sword"),
	inventory_image = "titaniumsword.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.2,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 2100},
	},
})

minetest.register_tool("ugx1:vanadiumkatana", {
	description = ("Vanadium Katana"),
	inventory_image = "vanadiumkatana.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 6,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 60}
	},
})

minetest.register_tool("ugx1:rustysword", {
	description = ("Rusty Steel Sword"),
	inventory_image = "rssw.png",
    wield_scale = {x = 2, y = 2, z = 1},
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.2,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 40,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 5},
	},
})

minetest.register_tool("ugx1:river_sword", {
    description = "Rivel Sword",
    inventory_image = "riversword.png",
    wield_scale = {x = 2, y = 2, z = 1},
    tool_capabilities = {
        max_drop_level = 3,
        groupcaps = {
            fleshy = {times = {[3] = 0, [4] = 0, [6] = 0}, uses = 0, maxlevel = 3},
            choppy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
            snappy = {times = {[1] = 0, [2] = 0, [3] = 0}, uses = 0, maxlevel = 3},
        },
        damage_groups = {fleshy = 15, cracky = 1, snappy = 3, choppy = 1, crumbly = 1},
    }
})

-- Shovel
minetest.register_tool("ugx1:hydro_shovel", {
	description = "Hydro Shovel",
	inventory_image = "hydroshovel.png",
    wield_scale = {x = 2, y = 2, z = 1},
	tool_capabilities = {
		max_drop_level=3,
		groupcaps={
			crumbly={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
		}
	},
})

-- axe
minetest.register_tool("ugx1:hydro_axe", {
	description = "Hydro Axe",
	inventory_image = "hydroaxe.png",
    wield_scale = {x = 2, y = 2, z = 1},
	tool_capabilities = {
		max_drop_level=3,
		groupcaps={
			fleshy = {times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			choppy={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
		}
	},
})

-- blocks

minetest.register_node("ugx1:default_dirt_y_minded", {
    description = "Dirty-Minded",
    tiles = {"dminded.png"},
    light_source = 1,
    groups = {cracky = 4},
})


minetest.register_node("ugx1:bluefeathers", {
    description = "Blue Feather",
    tiles = {"bluefeathers.png"},
    light_source = 1,
    groups = {cracky = 4},
})


minetest.register_node("ugx1:supercrystalblock", {
description = minetest.colorize("#703df2", "SUPER CRYSTAL BLOCK\n"),
    tiles = {"supercrystal.png"},
    light_source = 14,
    groups = {cracky = 4},
})

